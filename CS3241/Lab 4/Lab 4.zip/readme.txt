Name: Terence Chok
Matric: A0124503W

This lab assignment is the hardest because you have to click the control points to draw.

My drawing tries its best to look like a butterfly, with a lolipop antenna and a glittering body

Nothing special about my code, other than the heavy math-turned-into-algorithms part.